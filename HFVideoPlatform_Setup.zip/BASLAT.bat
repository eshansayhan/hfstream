@echo off
chcp 65001 > nul
cls

echo.
echo  ████████████████████████████████████████████████████████
echo  ██                                                    ██
echo  ██        HFVideoPlatform  ^|  Premium Streaming       ██
echo  ██        Node.js ^| Python ^| C++ Entegre Sistem       ██
echo  ██                                                    ██
echo  ████████████████████████████████████████████████████████
echo.
echo  [*] Baslatiliyor... Lutfen bekleyin.
echo.

:: =========================================================
:: 0. Eski calisan surecleri temizle (port catismasini onler)
:: =========================================================
echo  [0/3] Eski surecler temizleniyor (port 3000, 5000, 8080)...

for /f "tokens=5" %%p in ('netstat -aon 2^>nul ^| findstr ":3000 "') do (
    taskkill /F /PID %%p > nul 2>&1
)
for /f "tokens=5" %%p in ('netstat -aon 2^>nul ^| findstr ":5000 "') do (
    taskkill /F /PID %%p > nul 2>&1
)
for /f "tokens=5" %%p in ('netstat -aon 2^>nul ^| findstr ":8080 "') do (
    taskkill /F /PID %%p > nul 2>&1
)

:: Eski HFVideoPlatform.exe'yi de kapat
taskkill /F /IM HFVideoPlatform.exe > nul 2>&1

echo  [0/3] Temizlik tamamlandi.
echo.

:: =========================================================
:: 1. Node.js var mi kontrol et
:: =========================================================
where node > nul 2>&1
if %errorlevel% neq 0 (
    echo  [HATA] Node.js bulunamadi! Lutfen https://nodejs.org adresinden yukleyin.
    pause
    exit /b 1
)

:: =========================================================
:: 2. Python var mi kontrol et
:: =========================================================
where python > nul 2>&1
if %errorlevel% neq 0 (
    echo  [UYARI] Python bulunamadi. AI motoru baslatilmayacak.
    echo.
)

:: =========================================================
:: 3. start.js ile tum motorlari tek seferde baslat
:: =========================================================
echo  [*] Tum motorlar (C++ + Python + Node) baslatiliyor...
echo  [*] Tarayici otomatik acilacak. Acilmazsa: http://localhost:3000
echo.
echo  Durdurmak icin bu pencereyi kapatin veya CTRL+C basin.
echo  ========================================================
echo.

node "%~dp0start.js"

pause
